package com.example.women_safety_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
